function Q = vol_heat_gen(Qmax,z,H)
    % Qmax,z,H TODO
    Q = Qmax*cos(z.*pi./H);
end